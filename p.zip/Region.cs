﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Region
{
	public int color = Map.UNKNOWN;

	public int[] vertexList; // this is a list of pointers to the vertex list in map.
}
